function RED()
{
    var col = document.getElementById("section1");
    var col2 = document.getElementById("section2");
    var col3 = document.getElementById("section3");
    var col4 = document.getElementById("Section4");
    var col5 = document.getElementById("Section5");
    var col6 = document.getElementById("section6");
    var col7 = document.getElementById("Section7");
    col.style.background = 'red';
    col2.style.background = 'red';
    col3.style.background = 'red';
    col4.style.background = 'red';
    col5.style.background = 'red';
    col6.style.background = 'red';
    col7.style.background = 'red';

}
function ORANGE()
{
    var col = document.getElementById("section1");
    var col2 = document.getElementById("section2");
    var col3 = document.getElementById("section3");
    var col4 = document.getElementById("Section4");
    var col5 = document.getElementById("Section5");
    var col6 = document.getElementById("section6");
    var col7 = document.getElementById("Section7");
    col.style.background = 'ORANGE';
    col2.style.background = 'ORANGE';
    col3.style.background = 'ORANGE';
    col4.style.background = 'ORANGE';
    col5.style.background = 'ORANGE';
    col6.style.background = 'ORANGE';
    col7.style.background = 'ORANGE';
}
function PINK()
{
    var col = document.getElementById("section1");
    var col2 = document.getElementById("section2");
    var col3 = document.getElementById("section3");
    var col4 = document.getElementById("Section4");
    var col5 = document.getElementById("Section5");
    var col6 = document.getElementById("section6");
    var col7 = document.getElementById("Section7");
    col.style.background = 'pink';
    col2.style.background = 'pink';
    col3.style.background = 'pink';
    col4.style.background = 'pink';
    col5.style.background = 'pink';
    col6.style.background = 'pink';
    col7.style.background = 'pink';

}
function GREEN()
{
    var col = document.getElementById("section1");
    var col2 = document.getElementById("section2");
    var col3 = document.getElementById("section3");
    var col4 = document.getElementById("Section4");
    var col5 = document.getElementById("Section5");
    var col6 = document.getElementById("section6");
    var col7 = document.getElementById("Section7");
    col.style.background = 'green';
    col2.style.background = 'green';
    col3.style.background = 'green';
    col4.style.background = 'green';
    col5.style.background = 'green';
    col6.style.background = 'green';
    col7.style.background = 'green';

}
function YELLOW()
{
    var col = document.getElementById("section1");
    var col2 = document.getElementById("section2");
    var col3 = document.getElementById("section3");
    var col4 = document.getElementById("Section4");
    var col5 = document.getElementById("Section5");
    var col6 = document.getElementById("section6");
    var col7 = document.getElementById("Section7");
    col.style.background = 'yellow';
    col2.style.background = 'yellow';
    col3.style.background = 'yellow';
    col4.style.background = 'yellow';
    col5.style.background = 'yellow';
    col6.style.background = 'yellow';
    col7.style.background = 'yellow';
}
function fivepx()
{
    var col = document.getElementById("section1");
    var col2 = document.getElementById("section2");
    var col3 = document.getElementById("section3");
    var col4 = document.getElementById("Section4");
    var col5 = document.getElementById("Section5");
    var col6 = document.getElementById("section6");
    var col7 = document.getElementById("Section7");
    col.style.fontSize = '5px'; 
    col2.style.fontSize = '5px';
    col3.style.fontSize = '5px';
    col4.style.fontSize = '5px';
    col5.style.fontSize = '5px';
    col6.style.fontSize = '5px';
    col7.style.fontSize = '5px';

}
function thirtyfivepx()
{
    var col = document.getElementById("section1");
    var col2 = document.getElementById("section2");
    var col3 = document.getElementById("section3");
    var col4 = document.getElementById("Section4");
    var col5 = document.getElementById("Section5");
    var col6 = document.getElementById("section6");
    var col7 = document.getElementById("Section7");
    col.style.fontSize = '35px'; 
    col2.style.fontSize = '35px';
    col3.style.fontSize = '35px';
    col4.style.fontSize = '35px';
    col5.style.fontSize = '35px';
    col6.style.fontSize = '35px';
    col7.style.fontSize = '35px';

}
function fiftypx()
{
    var col = document.getElementById("section1");
    var col2 = document.getElementById("section2");
    var col3 = document.getElementById("section3");
    var col4 = document.getElementById("Section4");
    var col5 = document.getElementById("Section5");
    var col6 = document.getElementById("section6");
    var col7 = document.getElementById("Section7");
    col.style.fontSize = '50px'; 
    col2.style.fontSize = '50px';
    col3.style.fontSize = '50px';
    col4.style.fontSize = '50px';
    col5.style.fontSize = '50px';
    col6.style.fontSize = '50px';
    col7.style.fontSize = '50px';

}