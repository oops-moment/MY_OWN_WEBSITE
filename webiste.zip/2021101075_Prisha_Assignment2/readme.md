# DSA ASSIGNMENT 1 
## Prisha | 2021101075 | SECTION A
---
## Requirements

- Windows(MingW compiler) WORKING PERFECTLY FINE ON THAT

## QUESTION 1
NOTE: INTERNAL, INLINE , EXTERNAL CSS HAVE ALSO BEEN ADDED AS IN CSS FILE AND TAGS OF HTML FILE AS STYLE TAG OR INLINE CSS.
### 1.html file
- Head contains the link of 1st question CSS file and fontawesome link including via <link href>
- using **inline CSS** background color of body was set to sky.
- path to each section was provided via nav-bar like about, contact me etc clicking to respective link will take you to desired section.
- Total of 8 sections were created and each had its own background and background hover image.
**SECTION 1 CSS**
- Enlargement of image over hover.
- Change of Background color over hover.
- Text color change and fixation of nav bar..
**SECTION 2 CSS**
-  Change of Background color over hover.
- marquee over text 
- Conatins about me text aligned in table along with emoji
**SECTION 3 CSS**
- Table that deals with my educational background
- marquee over heading
- images were added of respective institution for better illustration.
**SECTION 4 CSS**
- Thus section contains acheivements along with their illustrating images
- bacground color changes when hovered
**SECTION 5 CSS**
- This section contains an internal link and a external link
- internal link will redirect you to my own site (local file)
- External will take you to my youtube art link!!
- Suitable background image and font style were added
**SECTION 6 CSS**
- It contains insert data table reference was taken from yt video to understand and the doc provided.
- User enters the data and gets inserted in local storage below.
- background image changes when hovered.
- Data keeps getting inserted in local storage.
**SECTION 7 CSS**
- It contains button to change font size and color when clicked
- Clicking on red will change everything in background to red

## QUESTION 2
- Uswer needs to enter the subjects seperated by space.